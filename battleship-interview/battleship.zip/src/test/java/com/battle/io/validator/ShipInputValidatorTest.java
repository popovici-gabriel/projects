package com.battle.io.validator;

import org.junit.Assert;
import org.junit.Test;

public class ShipInputValidatorTest
{

    @Test
    public void testValidate()
    {
	IValidator validator = new ShipInputValidator();
	Assert.assertTrue(validator.validate("(1,2,N) (3,2,E)"));
    }

    @Test
    public void testFailValidate()
    {
	IValidator validator = new ShipInputValidator();
	Assert.assertFalse(validator.validate("(1,2,R)"));
    }

}
