package com.battle.io.validator;

import org.junit.Assert;
import org.junit.Test;

public class BoundariesValidatorTest
{

    @Test
    public void testValidate()
    {
	IValidator validator = new BoundariesValidator();
	Assert.assertTrue(validator.validate("(3,3)"));
    }
}
