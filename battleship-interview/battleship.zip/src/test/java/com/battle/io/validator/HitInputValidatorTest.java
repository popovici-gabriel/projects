/**
 * 
 */
package com.battle.io.validator;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author gabi
 * 
 */
public class HitInputValidatorTest
{

    /**
     * Test method for
     * {@link com.battle.io.validator.HitInputValidator#validate(java.lang.String)}
     * .
     */
    @Test
    public void testValidate()
    {
	IValidator validator = new HitInputValidator();
	Assert.assertTrue(validator.validate("(2,3)"));
    }

    @Test
    public void testFailChars()
    {
	IValidator validator = new HitInputValidator();
	Assert.assertFalse(validator.validate("(s,d)"));
    }

}
