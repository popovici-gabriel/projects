package com.battle.io.validator;

import org.junit.Assert;
import org.junit.Test;

public class ShipMovementValidatorTest
{

    @Test
    public void testValidate()
    {
	IValidator validator = new ShipMovementValidator();
	Assert.assertTrue(validator.validate("(1,2) LRMLRM"));
    }

}
