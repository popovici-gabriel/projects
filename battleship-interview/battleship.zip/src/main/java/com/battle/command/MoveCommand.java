/**
 * 
 */
package com.battle.command;

import com.battle.model.Cell;
import com.battle.model.Grid;

/**
 * @author gabi
 * 
 */
public final class MoveCommand implements ICommand
{
    private Grid grid;

    /**
     * 
     */
    public MoveCommand(Grid grid)
    {
	this.grid = grid;
    }

    public Cell execute(Cell current)
    {
	return grid.move(current);
    }

}
