/**
 * 
 */
package com.battle.command;

import com.battle.model.Cell;

/**
 * @author gabi
 * 
 */
public final class RotateLeftCommand implements ICommand
{

    public RotateLeftCommand()
    {
	super();
    }

    public Cell execute(Cell current)
    {
	current.getShip().rotateLeft();
	return current;
    }

}
