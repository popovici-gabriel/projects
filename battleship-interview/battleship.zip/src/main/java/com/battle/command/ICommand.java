package com.battle.command;

import com.battle.model.Cell;

/**
 * @author gabi
 * 
 */
public interface ICommand
{
    Cell execute(Cell current);
}
