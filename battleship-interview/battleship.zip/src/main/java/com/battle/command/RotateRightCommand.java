/**
 * 
 */
package com.battle.command;

import com.battle.model.Cell;

/**
 * @author gabi
 * 
 */
public final class RotateRightCommand implements ICommand
{

    /**
     * 
     */
    public RotateRightCommand()
    {
	super();
    }

    public Cell execute(Cell current)
    {
	current.getShip().rotateRight();
	return current;
    }

}
