package com.battle.command;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.battle.model.Cell;
import com.battle.model.Grid;
import com.battle.model.Operation;

public class Commands
{
    private Map<Operation, ICommand> commands;

    public Commands(Grid grid)
    {
	super(); 
	this.commands = new HashMap<Operation, ICommand>(3);
	commands.put(Operation.L, new RotateLeftCommand());
	commands.put(Operation.R, new RotateRightCommand());
	commands.put(Operation.M, new MoveCommand(grid));
    }

    public Map<Operation, ICommand> commands()
    {
	return Collections.unmodifiableMap(this.commands);
    }

    private Cell initial;

    public Cell getInitial()
    {
	return initial;
    }

    public void setInitial(Cell initial)
    {
	this.initial = initial;
    }

}
