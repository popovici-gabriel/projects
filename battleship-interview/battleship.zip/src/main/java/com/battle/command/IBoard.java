package com.battle.command;

import com.battle.model.Grid;
import com.battle.model.Orientation;

/**
 * Operations on the board
 * 
 * @author gabi
 * 
 */
public interface IBoard
{
    /**
     * Setup initial board.
     * 
     * @param x
     *            rows
     * @param y
     *            columns
     */
    void setupGrid(int x, int y);

    /**
     * Add ship
     * 
     * @param x
     * @param y
     * @param orientation
     */
    void addShip(int x, int y, Orientation orientation);

    /**
     * Return current played grid.
     * 
     * @return {@link IBoard}
     */
    Grid getGrid();

    /**
     * Number of ships.
     * 
     * @return
     */
    int getNoShips();

    /**
     * @param x
     * @param y
     * @param command
     */
    void sendCommand(int x, int y, String command);

    /**
     * Hit at location.
     * 
     * @param x
     * @param y
     */
    boolean hitAtLocation(int x, int y);

    /**
     * This is used to exit the console loop.
     * 
     * @return boolean no more hits available start printing the result.
     */
    boolean shouldPrintResults();

    /**
     * Print to console
     */
    void print();
}
