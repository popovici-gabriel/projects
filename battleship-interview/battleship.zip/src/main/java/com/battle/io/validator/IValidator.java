package com.battle.io.validator;

public interface IValidator
{
    boolean validate(String input);
}
