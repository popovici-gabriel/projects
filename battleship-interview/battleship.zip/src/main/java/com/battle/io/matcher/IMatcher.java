/**
 * 
 */
package com.battle.io.matcher;

/**
 * @author gabi
 * 
 */
public interface IMatcher
{
    void match(String input);

    boolean isMatched();
}
