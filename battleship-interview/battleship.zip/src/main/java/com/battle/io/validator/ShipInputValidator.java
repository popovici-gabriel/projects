/**
 * 
 */
package com.battle.io.validator;

import java.util.regex.Pattern;

/**
 * @author Gabriel Popovici (popovici.gabriel@gmail.com)
 * 
 */
public class ShipInputValidator implements IValidator
{
    private static String SHIPS_EXPRESSION = "([(]\\d+,\\s?\\d+,\\s?[N|S|E|W][)]\\s?)+";

    private Pattern pattern;

    public ShipInputValidator()
    {
	super();
	pattern = Pattern.compile(SHIPS_EXPRESSION);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.battle.io.validator.IValidator#validate(java.lang.String)
     */
    public boolean validate(String input)
    {
	return pattern.matcher(input).matches();
    }

}
