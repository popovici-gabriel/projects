package com.battle.io.validator;

import java.util.regex.Pattern;

/**
 * Matches HIT Input. (x,y) <b/>
 * 
 * @author Gabriel Popovici (popovici.gabriel@gmail.com)
 * 
 */
public class HitInputValidator implements IValidator
{
    private static String COORDINATES_EXPRESSION = "[(]\\d+,\\s?\\d+[)]";

    private Pattern pattern;

    public HitInputValidator()
    {
	super();
	pattern = Pattern.compile(COORDINATES_EXPRESSION);
    }

    public boolean validate(String input)
    {
	return pattern.matcher(input).matches();
    }
    
    public static void main(String[] args)
    {
	IValidator v = new HitInputValidator(); 
	System.out.println(v.validate("(1, 2)"));
    }

}
