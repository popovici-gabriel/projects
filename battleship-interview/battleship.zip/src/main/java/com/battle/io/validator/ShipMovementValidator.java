package com.battle.io.validator;

import java.util.regex.Pattern;

/**
 * Ship Movement command on the board: <br/>
 * (2,2)space LRMLRM
 * 
 * @author Gabriel Popovici (popovici.gabriel@gmail.com)
 * 
 */
public class ShipMovementValidator implements IValidator
{
    private static String MOVEMENT_EXPRESSION = "[(]\\d+,\\s?\\d+[)]\\s{1}[L|R|M]+";

    private Pattern pattern;

    public ShipMovementValidator()
    {
	super();
	pattern = Pattern.compile(MOVEMENT_EXPRESSION);
    }

    public boolean validate(String input)
    {
	return pattern.matcher(input).matches();
    }

}
