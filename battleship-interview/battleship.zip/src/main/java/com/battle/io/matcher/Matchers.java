/**
 * 
 */
package com.battle.io.matcher;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.battle.command.IBoard;
import com.battle.extractor.Coordinates;
import com.battle.io.validator.BoundariesValidator;
import com.battle.io.validator.HitInputValidator;
import com.battle.io.validator.IValidator;
import com.battle.io.validator.ShipInputValidator;
import com.battle.io.validator.ShipMovementValidator;
import com.battle.model.Orientation;

/**
 * @author Gabriel Popovici (popovici.gabriel@gmail.com)
 * 
 */
public class Matchers
{
    public static class BoundariesMatcher implements IMatcher
    {
	private final IValidator validator;
	private final IBoard board;
	private boolean matched;
	private boolean init;

	public BoundariesMatcher(IValidator validator, IBoard board)
	{
	    super();
	    this.validator = validator;
	    this.board = board;
	    matched = false;
	    init = false;
	}

	public void match(String input)
	{
	    this.matched = validator.validate(input);
	    if (matched && !init)
	    {
		Coordinates c = Coordinates.build(input);
		board.setupGrid(c.getX(), c.getY());
		init = true;
	    }
	}

	public boolean isMatched()
	{
	    return matched;
	}
    }

    public static class ShipInputMatcher implements IMatcher
    {
	private final IValidator validator;
	private boolean matched;
	private final IBoard board;

	public ShipInputMatcher(IValidator validator, IBoard board)
	{
	    super();
	    this.validator = validator;
	    this.board = board;
	}

	public void match(String input)
	{
	    this.matched = validator.validate(input);
	    if (matched)
	    {
		Matcher matcher = Pattern.compile(
			"[(]\\d+,\\s?\\d+,\\s?[N|S|E|W][)]").matcher(input);
		while (matcher.find())
		{
		    Coordinates c = Coordinates.build(matcher.group());
		    board.addShip(c.getX(), c.getY(),
			    extractOrientation(matcher.group()));
		}
	    }
	}

	private Orientation extractOrientation(String input)
	{
	    Matcher matcher = Pattern.compile("[N|S|E|W]").matcher(input);
	    Orientation o = null;
	    while (matcher.find())
	    {
		o = Orientation.valueOf(matcher.group());
	    }

	    if (o == null)
		throw new RuntimeException(
			"Must input proper orientation: [N|S|E|W]");
	    return o;
	}

	public boolean isMatched()
	{
	    return matched;
	}
    }

    public static class ShipMovementMatcher implements IMatcher
    {
	private IValidator validator;
	private boolean matched;
	private final IBoard board;

	public ShipMovementMatcher(IValidator validator, final IBoard board)
	{
	    super();
	    this.validator = validator;
	    this.board = board;
	}

	public void match(String input)
	{
	    boolean valid = validator.validate(input);
	    if (valid)
	    {
		Coordinates c = Coordinates.build(input);
		board.sendCommand(c.getX(), c.getY(), extractCommand(input));
	    }
	}

	private String extractCommand(String input)
	{
	    Matcher matcher = Pattern.compile("[L|R|M]+").matcher(input);
	    String command = null;
	    while (matcher.find())
	    {
		command = matcher.group();
	    }

	    if (command == null)
		throw new RuntimeException("Must input proper data L|R|M");
	    return command;
	}

	public boolean isMatched()
	{
	    return matched;
	}
    }

    public static class HitMatcher implements IMatcher
    {

	private final IValidator validator;
	private final IBoard board;
	private boolean matched;

	public HitMatcher(IValidator validator, IBoard board)
	{
	    super();
	    this.validator = validator;
	    this.board = board;
	}

	public void match(String input)
	{
	    boolean valid = validator.validate(input);
	    if (valid)
	    {
		Coordinates coordinates = Coordinates.build(input);
		board.hitAtLocation(coordinates.getX(), coordinates.getY());
	    }
	}

	public boolean isMatched()
	{
	    return matched;
	}

    }

    private List<IMatcher> matchers = null;

    public Matchers(IBoard board)
    {
	super();

	matchers = new LinkedList<IMatcher>();
	matchers.add(new BoundariesMatcher(new BoundariesValidator(), board));
	matchers.add(new ShipInputMatcher(new ShipInputValidator(), board));
	matchers.add(new ShipMovementMatcher(new ShipMovementValidator(), board));
	matchers.add(new HitMatcher(new HitInputValidator(), board));
    }

    public List<IMatcher> getMatchers()
    {
	return Collections.unmodifiableList(this.matchers);
    }

    public void match(String line)
    {
	for (IMatcher iMatcher : matchers)
	{
	    if (!iMatcher.isMatched())
		iMatcher.match(line);
	}
    }

}
