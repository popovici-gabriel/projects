package com.battle.io.validator;

import java.util.regex.Pattern;

/**
 * Input must be validated according to input:[3,3] </br>
 * 
 * @author Gabriel Popovici (popovici.gabriel@gmail.com) </br>
 */
public class BoundariesValidator implements IValidator
{
    private static String UPPPER_RIGHT_EXPRESSION = "[(]\\d+,\\s?\\d+[)]";

    private Pattern pattern;

    public BoundariesValidator()
    {
	super();
	pattern = Pattern.compile(UPPPER_RIGHT_EXPRESSION);
    }

    public boolean validate(String input)
    {
	return pattern.matcher(input).matches();
    }

}
