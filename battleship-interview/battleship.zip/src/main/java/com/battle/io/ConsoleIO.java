package com.battle.io;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;

import com.battle.command.IBoard;
import com.battle.io.matcher.Matchers;
import com.battle.model.Board;

/**
 * Handle the console IO.
 * 
 * @author Gabriel Popovici (popovici.gabriel@gmail.com)
 */
/**
 * @author gabi
 * 
 */
public class ConsoleIO implements Cloneable
{
    final private static String EXIT = "quit";
    private Matchers matchers = null;
    private IBoard board = null;

    public ConsoleIO()
    {
	super();
	this.board = new Board();
	this.matchers = new Matchers(this.board);
    }

    /**
     * Welcome message.
     */
    private static void welcome()
    {
	System.out
		.println("---------->  Welcome to the BattleShip Game     <-------------");
	System.out
		.println("---------->  Your Host: Gabriel Popovici        <-------------");
	System.out
		.println("---------->  E-mail:popovici.gabriel@gmail.com  <-------------");
	System.out
		.println("---------->  Follow the rules on the screen:    <-------------");
	System.out
		.println("---------->  Quick input followed:              <-------------");
	System.out
		.println("---------->  Upper right corner (5,5):	  <-------------");
	System.out
		.println("---------->  Ships: (x1,y1,O1),..,(xn,yn,On)    <-------------");
	System.out
		.println("---------->  Ship movement: (x,y) LRLRRMMM      <-------------");
	System.out
		.println("---------->  Hit ship: (x,y)                    <-------------");
	System.out
		.println("---------->  At any time you can quit the game  <-------------");
	System.out
		.println("---------->  by pressing: quit followed by Enter<-------------");
	System.out
		.println("---------->  Thanks and enjoy the game   !      <-------------");

    }

    private static void error(Exception e)
    {
	System.err.println(e.toString());
    }

    @Override
    protected Object clone() throws CloneNotSupportedException
    {
	throw new CloneNotSupportedException("Only one instance is allowed.");
    }

    /**
     * Start reading from Input console for a sequence of commands.
     */
    public void start()
    {
	welcome();
	System.out.println();
	System.out.println("Input:");

	Reader console = null;
	try
	{
	    console = new BufferedReader(new InputStreamReader(System.in));
	    if (console != null)
	    {
		String line = "";
		while (!line.equals(EXIT))
		{
		    line = ((BufferedReader) console).readLine();
		    line = line.trim();
		    if (line.equals(EXIT))
			break;

		    matchers.match(line);
		    if (board.shouldPrintResults())
			break;
		}
		if (!line.equals(EXIT))
		    board.print();
	    }
	}
	catch (Exception e)
	{
	    error(e);
	}
	finally
	{
	    System.out.println("Done!");
	}
    }
}
