/**
 * 
 */
package com.battle.error;

/**
 * @author gabi
 * 
 */
public class InputError extends Exception
{
    private static final long serialVersionUID = -6232645302310748851L;

    public InputError(String message, Throwable cause)
    {
	super(message, cause);
    }

    public InputError(String message)
    {
	super(message);
    }

}