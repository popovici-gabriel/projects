package com.battle.extractor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Coordinates
{
    private final static String DIGITS = "\\d+";
    private final int x;
    private final int y;

    public Coordinates(int x, int y)
    {
	super();
	this.x = x;
	this.y = y;
    }

    public int getX()
    {
	return x;
    }

    public int getY()
    {
	return y;
    }

    public static Coordinates getXY(String input)
    {
	Matcher matcher = Pattern.compile(DIGITS).matcher(input);
	int count = 0, xx = -1, yy = -1;
	while (matcher.find())
	{
	    count++;
	    String group = matcher.group();
	    if (count == 1)
		xx = Integer.valueOf(group);

	    if (count == 2)
		yy = Integer.valueOf(group);
	}

	if (xx == -1 || yy == -1)
	    throw new RuntimeException(String.format("Input error: %s", input));

	return new Coordinates(xx, yy);
    }

    public static Coordinates build(String input)
    {
	return getXY(input);
    }

    public static void main(String[] args)
    {
	Coordinates c = Coordinates.build("(32, 91)");
	System.err.println(c.getX());
	System.err.println(c.getY());
    }
}
