package com.battle;

import com.battle.io.ConsoleIO;

/**
 * @author Gabriel Popovici (popovici.gabriel@gmail.com )
 * 
 */
public class Start
{

    public static void main(String[] args)
    {
	ConsoleIO console = new ConsoleIO();
	console.start();
    }
}
