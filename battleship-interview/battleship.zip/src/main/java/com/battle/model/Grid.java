package com.battle.model;

final public class Grid
{
    final private int rows;
    final private int cols;
    final private Cell[][] cells;
    private int count;
    private int remainingHits;

    public Grid(int rows, int cols)
    {
	super();

	this.count = 0;
	this.remainingHits = 0;
	this.rows = rows;
	this.cols = cols;
	this.cells = new Cell[rows][cols];
	setup();
    }

    public void setup()
    {
	for (int i = 0; i < rows; ++i)
	    for (int j = 0; j < cols; ++j)
		this.cells[i][j] = new Cell(i, j);
    }

    public void show()
    {
	if (cells == null)
	    throw new IllegalStateException("Grid has not been initialized");

	for (int i = 0; i < rows; i++)
	{
	    for (int j = 0; j < cols; j++)
		System.out.printf("%9.4s ", cells[i][j].hasShip() ? "S" : "-");
	    System.out.println();
	}
    }

    @Override
    public String toString()
    {
	StringBuilder builder = new StringBuilder();
	builder.append("Grid [rows=");
	builder.append(rows);
	builder.append(", cols=");
	builder.append(cols);
	builder.append(", ship counter=");
	builder.append(count);
	builder.append("]");
	return builder.toString();
    }

    public void addShip(int x, int y, Orientation orientation)
    {
	if (!validX(x) || !validY(y))
	{
	    System.err
		    .println(String
			    .format("Out of bounds. Ignoring last command.(\"%1d,%2d\")",
				    x, y));
	    return;
	}

	Cell cell = this.cells[x][y];
	cell.addShip(new Ship(orientation, Status.FLOATING));
	count++;
	remainingHits++;
    }

    private Cell addShipAtCoordinates(int x, int y, Orientation orientation)
    {
	Cell cell = this.cells[x][y];
	if (cell.hasShip())/* has already */
	    cell.addVisiting(new Ship(orientation, Status.FLOATING));
	else
	    cell.addShip(new Ship(orientation, Status.FLOATING));
	return cell;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException
    {
	throw new CloneNotSupportedException("Clone not supported !");
    }

    public int getCount()
    {
	return count;
    }

    public boolean hit(int x, int y)
    {
	if (!validX(x) || !validY(y))
	{
	    return false;
	}

	boolean success = false;
	Cell cell = this.cells[x][y];
	if (cell.hasShip())
	{
	    cell.hit();
	    success = true;
	}
	--remainingHits;
	return success;
    }

    public boolean validX(int x)
    {
	return ((x > 0) && (x < rows));
    }

    public boolean validY(int y)
    {
	return ((y > 0) && (y < cols));
    }

    public Cell getCell(int x, int y)
    {
	if (!validX(x) || !validY(y))
	{
	    System.err
		    .println(String
			    .format("Out of bounds. Ignoring last command.(\"%1d,%2d\")",
				    x, y));
	    return null;
	}

	return this.cells[x][y];
    }

    private Orientation getPreviousOrientation(Cell previous)
    {
	return (previous.hasVisitingShip() ? previous.getVisiting()
		.getOrientation() : previous.getShip().getOrientation());
    }

    public Cell move(Cell previous)
    {
	Cell cell = null;
	switch (getPreviousOrientation(previous))
	{
	    case N:
		if (previous.getY() + 1 < rows)
		{
		    cell = addShipAtCoordinates(previous.getX(),
			    previous.getY() + 1, Orientation.N);
		    free(previous);
		}
		break;
	    case W:
		if (previous.getX() - 1 > 0)
		{
		    cell = addShipAtCoordinates(previous.getX() - 1,
			    previous.getY(), Orientation.W);
		    free(previous);
		}
		break;
	    case S:
		if (previous.getY() - 1 > 0)
		{
		    cell = addShipAtCoordinates(previous.getX(),
			    previous.getY() - 1, Orientation.S);
		    free(previous);
		}
		break;
	    case E:
		if (previous.getX() + 1 < cols)
		{
		    cell = addShipAtCoordinates(previous.getX() + 1,
			    previous.getY(), Orientation.E);
		    free(previous);
		}
		break;
	    default:
		throw new RuntimeException("Unrecognized orientation !");
	}

	if (cell == null)
	    return previous;

	return cell;
    }

    private void free(Cell previous)
    {
	if (previous.hasVisitingShip())
	    previous.addVisiting(null);
	else
	    previous.setShip(null);
    }

    public boolean hasRemainingHits()
    {
	return ((this.count > 0) && (this.remainingHits == 0));
    }

    public void print()
    {
	if (cells == null)
	    throw new IllegalStateException("Grid has not been initialized");

	System.out.println("Output: ");
	for (int i = 0; i < rows; ++i)
	    for (int j = 0; j < cols; ++j)
	    {
		if (this.cells[i][j].hasShip())
		{
		    Cell cell = this.cells[i][j];
		    Status status = cell.getShip().getStatus();
		    String ss = status.equals(Status.SUNK) ? Status.SUNK
			    .toString() : "";
		    System.out.println(String.format("(%d, %d, %s) %s",
			    cell.getX(), cell.getY(), cell.getShip()
				    .getOrientation().toString(), ss));
		}
	    }
    }
}
