package com.battle.model;

public class Settings
{

    public Settings()
    {
    }

}
