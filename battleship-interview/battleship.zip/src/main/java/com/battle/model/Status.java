/**
 * 
 */
package com.battle.model;

/**
 * @author gabi
 * 
 */
public enum Status
{
    SUNK, FLOATING;
}
