package com.battle.model;

/**
 * A Ship occupies a Cell in a grid
 * 
 * @author gabe
 * 
 */
public class Cell
{
    private int x;
    private int y;

    /**
     * Main ship
     */
    private Ship ship;

    /**
     * Visiting ship when moving command
     */
    private Ship visiting;

    public Cell(int x, int y)
    {
	super();
	this.x = x;
	this.y = y;
    }

    public Cell(int x, int y, Ship ship)
    {
	super();
	this.x = x;
	this.y = y;
	this.ship = ship;
    }

    public int getX()
    {
	return x;
    }

    public void setX(int x)
    {
	this.x = x;
    }

    public int getY()
    {
	return y;
    }

    public void setY(int y)
    {
	this.y = y;
    }

    @Override
    public int hashCode()
    {
	final int prime = 31;
	int result = 1;
	result = prime * result + x;
	result = prime * result + y;
	return result;
    }

    @Override
    public boolean equals(Object obj)
    {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	Cell other = (Cell) obj;
	if (x != other.x)
	    return false;
	if (y != other.y)
	    return false;
	return true;
    }

    public void addShip(Ship ship)
    {
	this.ship = ship;
    }

    public boolean hasShip()
    {
	return ship != null;
    }

    public void hit()
    {
	this.ship.setStatus(Status.SUNK);
    }

    @Override
    public String toString()
    {
	StringBuilder builder = new StringBuilder();
	builder.append("Cell [x=");
	builder.append(x);
	builder.append(", y=");
	builder.append(y);
	builder.append(", ship=");
	builder.append(ship);
	builder.append("]");
	return builder.toString();
    }

    public void addVisiting(Ship visiting)
    {
	this.visiting = visiting;
    }

    public boolean hasVisitingShip()
    {
	return visiting != null;
    }

    public Ship getShip()
    {
	return ship;
    }

    public Ship getVisiting()
    {
	return visiting;
    }

    public void setShip(Ship ship)
    {
	this.ship = ship;
    }

}
