package com.battle.model;

/**
 * Model of the ship
 * 
 * @author gabe
 * 
 */
public class Ship
{
    private Orientation orientation;
    private Status status;

    public Ship(Orientation orientation, Status status)
    {
	super();
	this.orientation = orientation;
	this.status = status;
    }

    public Orientation getOrientation()
    {
	return orientation;
    }

    public void setOrientation(Orientation orientation)
    {
	this.orientation = orientation;
    }

    public Status getStatus()
    {
	return status;
    }

    public void setStatus(Status status)
    {
	this.status = status;
    }

    @Override
    public String toString()
    {
	StringBuilder builder = new StringBuilder();
	builder.append("Ship [orientation=");
	builder.append(orientation);
	builder.append(", status=");
	builder.append(status);
	builder.append("]");
	return builder.toString();
    }

    public void rotateLeft()
    {
	switch (orientation)
	{
	    case N:
		this.orientation = Orientation.W;
		break;
	    case W:
		this.orientation = Orientation.S;
		break;
	    case S:
		this.orientation = Orientation.E;
		break;
	    case E:
		this.orientation = Orientation.N;
		break;
	    default:
		throw new RuntimeException("Unrecognized orientation !");
	}
    }

    public void rotateRight()
    {
	switch (orientation)
	{
	    case N:
		this.orientation = Orientation.E;
		break;
	    case E:
		this.orientation = Orientation.S;
		break;
	    case S:
		this.orientation = Orientation.W;
		break;
	    case W:
		this.orientation = Orientation.N;
		break;
	    default:
		throw new RuntimeException("Unrecognized orientation !");
	}
    }

}