package com.battle.model;

public enum Operation
{
    L, R, M;
}
