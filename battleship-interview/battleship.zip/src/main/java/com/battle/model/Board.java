package com.battle.model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.battle.command.Commands;
import com.battle.command.IBoard;

/**
 * Board operations.
 * 
 * @author gabi
 * 
 */
public class Board implements IBoard
{
    private Grid grid = null;

    public Board()
    {
    }

    public void setupGrid(int x, int y)
    {
	this.grid = new Grid(x, y);
    }

    public void addShip(int x, int y, Orientation orientation)
    {
	this.grid.addShip(x, y, orientation);
    }

    public Grid getGrid()
    {
	return grid;
    }

    public int getNoShips()
    {
	return grid.getCount();
    }

    public void sendCommand(int x, int y, String command)
    {
	Cell cell = grid.getCell(x, y);
	if (cell != null)
	{
	    if (!cell.hasShip())
	    {
		System.err
			.println("Ship localization failed. Ignoring command.");
		return;
	    }

	    Cell current = cell;
	    Commands cmds = new Commands(grid);
	    cmds.setInitial(current);

	    Matcher matcher = Pattern.compile("[L|R|M]").matcher(command);
	    while (matcher.find())
	    {
		current = cmds.commands()
			.get(Operation.valueOf(matcher.group()))
			.execute(current);
	    }

	    if (current.hasVisitingShip())
	    {
		System.err.println(String.format("Initial: (%d,%d) to current: (%d,%d) commands: %s", 
			                          cell.getX(),cell.getY(),
			                          current.getX(), cell.getY(),
			                          command));
		throw new RuntimeException(
			"A square can’t be occupied by more than one ship !");
	    }
	}
    }

    public boolean hitAtLocation(int x, int y)
    {
	return grid.hit(x, y);
    }

    public boolean shouldPrintResults()
    {
	if (grid == null)
	    return false;
	return grid.hasRemainingHits();
    }

    public void print()
    {
	if (grid == null)
	    return;
	this.grid.print();
    }
}
