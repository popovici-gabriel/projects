package com.battle.model;

public enum Orientation
{
    N, S, W, E;
}
